import WebRenderGenerator from './WebRenderGenerator'
import NativeRenderGenerator from './NativeRenderGenerator'

export {
  WebRenderGenerator,
  NativeRenderGenerator
}
