import model from './model'
import html from './html'
import text from './text'

export {
	model,
	html,
	text
}
