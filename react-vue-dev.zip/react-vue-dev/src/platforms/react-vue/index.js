/** @flow */

import Vue from 'core/index'
import observer from './observer'

Vue.observer = observer

export default Vue
