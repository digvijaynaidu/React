import {
  buildInputComponent
} from './buildInputComponent'

const buildWebInputComponent = buildInputComponent

export {
  buildWebInputComponent
}
