export { resolveFilter } from 'core/instance/render-helpers/resolve-filter'
