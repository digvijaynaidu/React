export function template (props) {
  return props.children
}
