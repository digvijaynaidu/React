export { renderList } from 'core/instance/render-helpers/render-list'
