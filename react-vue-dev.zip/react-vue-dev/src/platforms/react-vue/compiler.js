/* @flow */

export { parseComponent } from 'sfc/parser'
export * from './compiler/index.js'
