/* @flow */

import bind from './bind'
import { noop } from 'shared/util'

export default {
  bind,
  cloak: noop
}
