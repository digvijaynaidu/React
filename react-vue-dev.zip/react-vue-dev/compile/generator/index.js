const ReactWebRenderGenerator = require('./ReactWebRenderGenerator')

module.exports = {
  ReactWebRenderGenerator
}
