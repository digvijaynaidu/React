const isReservedTag = require('./element')
const genHandlers = require('./events')

module.exports = {
  isReservedTag,
  genHandlers
}
